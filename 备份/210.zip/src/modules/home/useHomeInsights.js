export function getMonthStats(items = [], now = new Date()) {
  const y = now.getFullYear()
  const m = now.getMonth() + 1
  const monthItems = items.filter((i) => {
    if (i?.status !== 'sold') return false
    const d = i?.saleDetails?.date || ''
    if (!d) return false
    const dt = new Date(d)
    return dt.getFullYear() === y && dt.getMonth() + 1 === m
  })

  const revenue = monthItems.reduce((s, i) => s + Number(i?.saleDetails?.price || 0), 0)
  const cost = monthItems.reduce((s, i) => s + Number(i?.cost || 0), 0)
  const profit = monthItems.reduce((s, i) => s + Number(i?.saleDetails?.profit || 0), 0)
  return { revenue, cost, profit }
}

export function getLast3MonthsStats(items = [], now = new Date()) {
  const result = []
  for (let i = 0; i < 3; i += 1) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const year = d.getFullYear()
    const month = d.getMonth() + 1
    const monthItems = items.filter((it) => {
      if (it?.status !== 'sold') return false
      const sd = it?.saleDetails?.date
      if (!sd) return false
      const dt = new Date(sd)
      return dt.getFullYear() === year && dt.getMonth() + 1 === month
    })

    const revenue = monthItems.reduce((s, it) => s + Number(it?.saleDetails?.price || 0), 0)
    const cost = monthItems.reduce((s, it) => s + Number(it?.cost || 0), 0)
    const profit = monthItems.reduce((s, it) => s + Number(it?.saleDetails?.profit || 0), 0)

    result.push({ year, month, count: monthItems.length, revenue, cost, profit })
  }
  return result
}

export function getPurchaseStatus(items = []) {
  const purchaseItems = items.filter((i) => i?.status === 'purchase')
  const inProgressAmount = purchaseItems.reduce((s, i) => s + Number(i?.cost || 0), 0)
  const purchaseAmount = purchaseItems.reduce((s, i) => s + Number(i?.purchaseDetails?.preTransferCost || 0), 0)
  const transferAmount = purchaseItems.reduce((s, i) => s + Number(i?.purchaseDetails?.transferCost || 0), 0)
  const pendingCount = purchaseItems.filter(
    (i) => (i?.purchaseDetails?.transferStatus || 'pending') === 'pending',
  ).length

  return {
    count: purchaseItems.length,
    inProgressAmount,
    purchaseAmount,
    transferAmount,
    pendingCount,
    totalCost: inProgressAmount,
  }
}

export function getBatchReturnStats(items = []) {
  const batchMap = {}
  const categoryMap = {
    '2025JAPAN': { category: '2025JAPAN', totalCost: 0, revenue: 0 },
    美淘: { category: '美淘', totalCost: 0, revenue: 0 },
    日淘: { category: '日淘', totalCost: 0, revenue: 0 },
    国内: { category: '国内', totalCost: 0, revenue: 0 },
  }

  const categoryOrder = { '2025JAPAN': 1, 美淘: 2, 日淘: 3, 国内: 4 }
  const batchOrder = {
    美淘: { A组上半年: 1, A组下半年: 2, B组下半年: 3, '26上半年': 4 },
    日淘: { a批: 1, b批: 2, d批: 3, 预订: 4, 预订批: 4, '26d批': 5, '26e批': 6, '26f批': 7 },
  }

  // 成本口径：批次/分类/汇总统一使用「全量成本」

  const allCostMap = {}
  const allCategoryCostMap = {}
  items.forEach((item) => {
    const key = `${item?.category}|${item?.batch}`
    allCostMap[key] = (allCostMap[key] || 0) + Number(item?.cost || 0)
    allCategoryCostMap[item?.category] = (allCategoryCostMap[item?.category] || 0) + Number(item?.cost || 0)
    if (!batchMap[key]) {
      batchMap[key] = {
        category: item?.category,
        batch: item?.batch,
        totalCost: 0,
        revenue: 0,
      }
    }
  })

  // 旧版关键口径：销售额先按 sid+日期 去重分组，按单笔成交累加
  const saleGroups = {}
  items.forEach((item) => {
    if (item?.status !== 'sold') return
    const groupKey = `${item?.sid || ''}|${item?.saleDetails?.date || ''}`
    if (!saleGroups[groupKey]) {
      saleGroups[groupKey] = {
        sid: item?.sid,
        category: item?.category,
        batch: item?.batch,
        price: Number(item?.totalPrice || item?.saleDetails?.price || 0),
      }
    }
  })

  Object.values(saleGroups).forEach((sale) => {
    const key = `${sale.category}|${sale.batch}`
    if (!batchMap[key]) {
      batchMap[key] = { category: sale.category, batch: sale.batch, totalCost: 0, revenue: 0 }
    }
    batchMap[key].revenue += sale.price

    if (categoryMap[sale.category]) {
      categoryMap[sale.category].revenue += sale.price
    }
  })

  Object.keys(batchMap).forEach((key) => {
    batchMap[key].totalCost = Number(allCostMap[key] || 0)
  })

  Object.keys(categoryMap).forEach((cat) => {
    categoryMap[cat].totalCost = Number(allCategoryCostMap[cat] || 0)
  })

  const categoryResults = Object.values(categoryMap)
    .map((c) => ({
      ...c,
      batch: '',
      isCategory: true,
      rate: c.totalCost > 0 ? (c.revenue / c.totalCost) * 100 : 0,
    }))
    .filter((c) => c.totalCost > 0)

  const batchResults = Object.values(batchMap).map((b) => ({
    ...b,
    rate: b.totalCost > 0 ? (b.revenue / b.totalCost) * 100 : 0,
  }))

  const sortedBatches = batchResults.sort((a, b) => {
    const catOrderA = categoryOrder[a.category] || 99
    const catOrderB = categoryOrder[b.category] || 99
    if (catOrderA !== catOrderB) return catOrderA - catOrderB

    const orderA = batchOrder[a.category]?.[a.batch] || 99
    const orderB = batchOrder[b.category]?.[b.batch] || 99
    return orderA - orderB
  })

  const sortedCategories = categoryResults.sort((a, b) => {
    const orderA = categoryOrder[a.category] || 99
    const orderB = categoryOrder[b.category] || 99
    return orderA - orderB
  })

  const result = []
  sortedCategories.forEach((cat) => {
    result.push(cat)
    result.push(...sortedBatches.filter((b) => b.category === cat.category))
  })

  let allTotalCost = 0
  let allRevenue = 0
  Object.keys(allCostMap).forEach((k) => {
    allTotalCost += Number(allCostMap[k] || 0)
  })
  Object.values(batchMap).forEach((b) => {
    allRevenue += b.revenue
  })

  result.push({
    category: '汇总',
    batch: '',
    totalCost: allTotalCost,
    revenue: allRevenue,
    rate: allTotalCost > 0 ? (allRevenue / allTotalCost) * 100 : 0,
    isCategory: false,
    isSummary: true,
  })

  return result
}

export function searchItems(items = [], keyword = '') {
  const kw = String(keyword || '').trim().toLowerCase()
  if (!kw) return []
  return items.filter((item) => {
    const text = `${item?.sid || ''} ${item?.name || ''} ${item?.brand || ''}`.toLowerCase()
    return text.includes(kw)
  })
}
