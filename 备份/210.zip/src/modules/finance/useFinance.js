// 公共收支模块逻辑层（无 UI）

import { addOperationLog, saveToLocalStorage, state as store } from '../../data/store'

function toNumber(value, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? n : fallback
}

function genId() {
  return Date.now() + Math.floor(Math.random() * 1000)
}

function isLoanRepaid(loan) {
  if (typeof loan?.isRepaid === 'boolean') return loan.isRepaid
  if (typeof loan?.repaid === 'boolean') return loan.repaid
  return false
}

export function addFinanceRecord(recordData = {}) {
  const record = {
    id: genId(),
    type: recordData.type,
    date: recordData.date || '',
    item: recordData.item || '',
    amount: toNumber(recordData.amount),
    note: recordData.note || '',
  }

  store.financeRecords.push(record)
  saveToLocalStorage()
  addOperationLog('finance_add_record', `新增收支: ${record.item}`, { type: record.type, amount: record.amount })
  return record
}

export function deleteFinanceRecord(recordId) {
  const idx = store.financeRecords.findIndex((x) => x.id === recordId)
  if (idx < 0) return false

  store.financeRecords.splice(idx, 1)
  saveToLocalStorage()
  addOperationLog('finance_delete_record', `删除收支记录`, { recordId })
  return true
}

export function addLoanRecord(loanData = {}) {
  const loan = {
    id: genId(),
    type: loanData.type,
    date: loanData.date || '',
    counterparty: loanData.counterparty || '',
    amount: toNumber(loanData.amount),
    note: loanData.note || '',
    isRepaid: false,
    // 兼容旧字段
    repaid: false,
  }

  store.loanRecords.push(loan)
  saveToLocalStorage()
  addOperationLog('finance_add_loan', `新增借贷`, { type: loan.type, amount: loan.amount })
  return loan
}

export function markLoanRepaid(loanId) {
  const loan = store.loanRecords.find((x) => x.id === loanId)
  if (!loan) return false

  loan.isRepaid = true
  loan.repaid = true
  saveToLocalStorage()
  addOperationLog('finance_repaid', `标记已还`, { loanId })
  return loan
}

export function deleteLoanRecord(loanId) {
  const idx = store.loanRecords.findIndex((x) => x.id === loanId)
  if (idx < 0) return false

  store.loanRecords.splice(idx, 1)
  saveToLocalStorage()
  addOperationLog('finance_delete_loan', `删除借贷`, { loanId })
  return true
}

export function getFinanceStats(financeRecords = [], loanRecords = []) {
  const totalIncome = financeRecords.reduce(
    (sum, r) => (r?.type === 'income' ? sum + toNumber(r.amount) : sum),
    0,
  )

  const totalExpense = financeRecords.reduce(
    (sum, r) => (r?.type === 'expense' ? sum + toNumber(r.amount) : sum),
    0,
  )

  const totalBorrowed = loanRecords.reduce(
    (sum, r) => (r?.type === 'borrow' && !isLoanRepaid(r) ? sum + toNumber(r.amount) : sum),
    0,
  )

  const totalLent = loanRecords.reduce(
    (sum, r) => (r?.type === 'lend' && !isLoanRepaid(r) ? sum + toNumber(r.amount) : sum),
    0,
  )

  return {
    totalIncome,
    totalExpense,
    netBalance: totalIncome - totalExpense,
    totalBorrowed,
    totalLent,
    netLoan: totalBorrowed - totalLent,
  }
}

export function useFinance() {
  return {
    addFinanceRecord,
    deleteFinanceRecord,
    addLoanRecord,
    markLoanRepaid,
    deleteLoanRecord,
    getFinanceStats,
  }
}
