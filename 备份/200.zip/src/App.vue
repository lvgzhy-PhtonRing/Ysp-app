<script setup>
import { computed, onMounted, ref } from 'vue'
import AppSidebar from './components/AppSidebar.vue'
import GlassModal from './components/GlassModal.vue'
import HomeModule from './modules/home/HomeModule.vue'
import InventoryModule from './modules/inventory/InventoryModule.vue'
import PurchaseModule from './modules/purchase/PurchaseModule.vue'
import SalesModule from './modules/sales/SalesModule.vue'
import FinanceModule from './modules/finance/FinanceModule.vue'
import PaytonModule from './modules/payton/PaytonModule.vue'
import {
  addOperationLog,
  clearOperationLogs,
  exportData,
  loadData,
  loadFromLocalStorage,
  loadUiStateFromLocalStorage,
  saveToLocalStorage,
  saveUiStateToLocalStorage,
  state as store,
} from './data/store'

const tabs = [
  { id: 'home', name: '数据透视' },
  { id: 'inventory', name: '库存管理' },
  { id: 'sales', name: '销售记账' },
  { id: 'purchase', name: '采购管理' },
  { id: 'finance', name: '公共收支' },
  { id: 'payton', name: "Payton's基金" },
]

const currentTab = ref('home')
const fileInputRef = ref(null)
const showWebdavSettings = ref(false)
const showLogsModal = ref(false)
const logTypeMeta = {
  app_import: { label: '导入', color: 'text-teal-600', icon: 'fa-solid fa-upload' },
  app_export: { label: '导出', color: 'text-blue-600', icon: 'fa-solid fa-download' },
  webdav_settings: { label: 'WebDAV', color: 'text-indigo-600', icon: 'fa-solid fa-cloud' },
  purchase_add: { label: '采购', color: 'text-yellow-600', icon: 'fa-solid fa-plus' },
  purchase_transfer: { label: '转运', color: 'text-amber-600', icon: 'fa-solid fa-truck' },
  purchase_edit: { label: '采购编辑', color: 'text-blue-600', icon: 'fa-solid fa-pen' },
  purchase_delete: { label: '采购删除', color: 'text-red-600', icon: 'fa-solid fa-trash' },
  purchase_to_inventory: { label: '移入库存', color: 'text-green-600', icon: 'fa-solid fa-box' },
  purchase_batch_to_inventory: { label: '批量入库', color: 'text-green-600', icon: 'fa-solid fa-boxes-stacked' },
  inventory_manual_add: { label: '手动入库', color: 'text-blue-600', icon: 'fa-solid fa-bolt' },
  inventory_edit: { label: '库存编辑', color: 'text-blue-600', icon: 'fa-solid fa-pen' },
  inventory_unlist: { label: '下架', color: 'text-amber-600', icon: 'fa-solid fa-arrow-down' },
  inventory_delete: { label: '库存删除', color: 'text-red-600', icon: 'fa-solid fa-trash' },
  sales_submit: { label: '销售', color: 'text-green-600', icon: 'fa-solid fa-cash-register' },
  sales_edit: { label: '销售编辑', color: 'text-blue-600', icon: 'fa-solid fa-pen' },
  sales_rollback: { label: '销售回滚', color: 'text-red-600', icon: 'fa-solid fa-rotate-left' },
  finance_add_record: { label: '收支', color: 'text-indigo-600', icon: 'fa-solid fa-receipt' },
  finance_delete_record: { label: '收支删除', color: 'text-red-600', icon: 'fa-solid fa-trash' },
  finance_add_loan: { label: '借贷', color: 'text-yellow-600', icon: 'fa-solid fa-hand-holding-dollar' },
  finance_repaid: { label: '已还', color: 'text-gray-600', icon: 'fa-solid fa-check' },
  finance_delete_loan: { label: '借贷删除', color: 'text-red-600', icon: 'fa-solid fa-trash' },
  payton_add_record: { label: '基金流水', color: 'text-teal-600', icon: 'fa-solid fa-wallet' },
  payton_edit_record: { label: '基金编辑', color: 'text-blue-600', icon: 'fa-solid fa-pen' },
  payton_delete_record: { label: '基金删除', color: 'text-red-600', icon: 'fa-solid fa-trash' },
  payton_add_car: { label: '新增小车', color: 'text-green-600', icon: 'fa-solid fa-car' },
  payton_sell_car: { label: '卖车', color: 'text-purple-600', icon: 'fa-solid fa-coins' },
  home_calc: { label: '计算器', color: 'text-blue-600', icon: 'fa-solid fa-calculator' },
}

function getLogMeta(type) {
  return logTypeMeta[type] || { label: type, color: 'text-gray-500', icon: 'fa-solid fa-circle-info' }
}

const webdavForm = ref({
  url: '',
  username: '',
  password: '',
  enabled: false,
})

function getToday() {
  return new Date().toISOString().slice(0, 10)
}

const currentDate = computed(() => {
  const d = new Date()
  const yyyy = d.getFullYear()
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return `${yyyy}${mm}${dd}`
})

function triggerImport() {
  fileInputRef.value?.click()
}

function handleImport(event) {
  const file = event.target.files?.[0]
  if (!file) return

  const reader = new FileReader()
  reader.onload = (e) => {
    try {
      const json = JSON.parse(e.target?.result)
      loadData(json)
      saveToLocalStorage()
      addOperationLog('app_import', '导入数据成功', { file: file.name })
      alert('导入成功')
    } catch (err) {
      alert(`导入失败：${err.message}`)
    }
  }
  reader.readAsText(file)
  event.target.value = ''
}

function handleExport() {
  const data = exportData()
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `饮食派数据_${currentDate.value}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
  addOperationLog('app_export', '导出备份', { fileName: a.download })
}

function openWebdavSettings() {
  webdavForm.value = {
    url: store.webdavSettings.url || '',
    username: store.webdavSettings.username || '',
    password: store.webdavSettings.password || '',
    enabled: !!store.webdavSettings.enabled,
  }
  showWebdavSettings.value = true
}

function saveWebdavSettings() {
  Object.assign(store.webdavSettings, webdavForm.value)
  saveUiStateToLocalStorage()
  addOperationLog('webdav_settings', '更新WebDAV配置', {
    url: webdavForm.value.url,
    enabled: webdavForm.value.enabled,
  })
  showWebdavSettings.value = false
}

async function uploadToWebdav() {
  if (!webdavForm.value.url) {
    alert('请先配置WebDAV地址')
    return
  }
  try {
    const data = exportData()
    const filename = `饮食派数据_${getToday()}.json`
    const target = `${webdavForm.value.url}/${filename}`
    const auth = btoa(`${webdavForm.value.username || ''}:${webdavForm.value.password || ''}`)
    const res = await fetch(target, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${auth}`,
      },
      body: JSON.stringify(data),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    addOperationLog('webdav_upload', 'WebDAV上传成功', { file: filename })
    alert('数据上传成功')
  } catch (err) {
    alert(`上传失败: ${err.message}`)
  }
}

async function downloadFromWebdav() {
  if (!webdavForm.value.url) {
    alert('请先配置WebDAV地址')
    return
  }
  try {
    const filename = `饮食派数据_${getToday()}.json`
    const target = `${webdavForm.value.url}/${filename}`
    const auth = btoa(`${webdavForm.value.username || ''}:${webdavForm.value.password || ''}`)
    const res = await fetch(target, {
      method: 'GET',
      headers: {
        Authorization: `Basic ${auth}`,
      },
    })
    if (!res.ok) throw new Error('文件不存在')
    const data = await res.json()
    if (!confirm('确定要下载并覆盖当前数据吗？')) return
    loadData(data)
    saveToLocalStorage()
    addOperationLog('webdav_download', 'WebDAV下载成功', { file: filename })
    alert('数据下载成功')
  } catch (err) {
    alert(`下载失败: ${err.message}`)
  }
}

onMounted(() => {
  loadFromLocalStorage()
  loadUiStateFromLocalStorage()
})
</script>

<template>
  <div class="flex h-screen overflow-hidden bg-appbg text-gray-800" v-cloak>
    <input
      ref="fileInputRef"
      type="file"
      accept="application/json,.json"
      class="hidden"
      @change="handleImport"
    />

    <AppSidebar
      :tabs="tabs"
      :current-tab="currentTab"
      :version="store.version"
      @select="currentTab = $event"
      @import="triggerImport"
      @export="handleExport"
      @webdav="openWebdavSettings"
      @logs="showLogsModal = true"
    />

    <main class="flex-1 overflow-y-auto p-8">
      <div class="mx-auto max-w-7xl space-y-6 pb-8">
        <HomeModule v-if="currentTab === 'home'" />
        <InventoryModule v-else-if="currentTab === 'inventory'" />
        <SalesModule v-else-if="currentTab === 'sales'" />
        <PurchaseModule v-else-if="currentTab === 'purchase'" />
        <FinanceModule v-else-if="currentTab === 'finance'" />
        <PaytonModule v-else-if="currentTab === 'payton'" />

        <div
          v-else
          class="apple-card p-8 text-sm text-gray-500"
        >
          {{ tabs.find((t) => t.id === currentTab)?.name }} 模块 UI 开发中…
        </div>
      </div>
    </main>

    <GlassModal v-model="showWebdavSettings" panel-class="w-full max-w-md p-6 relative" :close-on-overlay="true">
      <div class="mb-6 text-xl font-bold">WebDAV同步设置</div>
      <div class="space-y-4">
        <div>
          <label class="block text-sm mb-1 text-gray-600">WebDAV地址</label>
          <input v-model="webdavForm.url" class="apple-input" placeholder="https://dav.jianguoyun.com/dav/" />
        </div>
        <div>
          <label class="block text-sm mb-1 text-gray-600">用户名</label>
          <input v-model="webdavForm.username" class="apple-input" placeholder="WebDAV用户名" />
        </div>
        <div>
          <label class="block text-sm mb-1 text-gray-600">密码</label>
          <input v-model="webdavForm.password" class="apple-input" type="password" placeholder="应用密码" />
        </div>
      </div>
      <div class="mt-8 flex justify-end gap-3">
        <button class="btn btn-outline" @click="showWebdavSettings = false">取消</button>
        <button class="btn btn-primary" @click="saveWebdavSettings">保存设置</button>
      </div>
      <div class="mt-3 flex gap-3">
        <button class="btn btn-outline flex-1" :disabled="!webdavForm.url" @click="uploadToWebdav">上传数据</button>
        <button class="btn btn-outline flex-1" :disabled="!webdavForm.url" @click="downloadFromWebdav">下载数据</button>
      </div>
    </GlassModal>

    <GlassModal v-model="showLogsModal" panel-class="w-full max-w-2xl relative max-h-[80vh] flex flex-col p-0" :close-on-overlay="true">
      <div class="px-4 py-4 border-b border-gray-100 flex items-center justify-between">
        <h3 class="text-xl font-bold">操作日志 <span class="text-sm font-normal text-gray-500">(近7天)</span></h3>
        <button class="btn btn-outline btn-sm" @click="clearOperationLogs">清空日志</button>
      </div>
      <div class="flex-1 overflow-y-auto space-y-2 p-4">
        <div v-if="store.operationLogs.length === 0" class="text-center text-gray-400 py-8">暂无日志记录</div>
        <div v-for="log in store.operationLogs.slice(0, 100)" :key="log.id" class="p-3 rounded-lg bg-gray-50 hover:bg-gray-100">
          <div class="flex justify-between items-start">
            <div class="flex items-start gap-2">
              <span class="inline-block px-2 py-0.5 rounded text-xs font-medium shrink-0" :class="{
                'bg-blue-100 text-blue-700': log.type === 'purchase_add',
                'bg-green-100 text-green-700': log.type === 'sales_submit' || log.type === 'payton_sell_car',
                'bg-yellow-100 text-yellow-700': log.type === 'purchase_transfer' || log.type === 'purchase_batch_to_inventory',
                'bg-purple-100 text-purple-700': log.type === 'inventory_edit' || log.type === 'sales_edit' || log.type === 'purchase_transfer_edit',
                'bg-red-100 text-red-700': log.type === 'purchase_delete' || log.type === 'inventory_delete' || log.type === 'sales_rollback' || log.type === 'purchase_transfer_delete',
                'bg-orange-100 text-orange-700': log.type === 'inventory_unlist',
                'bg-gray-100 text-gray-700': log.type === 'inventory_manual_add' || log.type === 'purchase_to_inventory',
                'bg-teal-100 text-teal-700': log.type === 'payton_add_record' || log.type === 'payton_edit_record' || log.type === 'payton_delete_record',
                'bg-indigo-100 text-indigo-700': log.type === 'webdav_settings' || log.type === 'webdav_upload' || log.type === 'webdav_download'
              }">{{ getLogMeta(log.type).label }}</span>
              <div>
                <span class="text-sm text-gray-800">{{ log.message }}</span>
                <div v-if="log.detail && Object.keys(log.detail).length > 0" class="mt-1 text-xs text-gray-400">
                  <span v-if="log.detail.qty">数量: {{ log.detail.qty }}</span>
                  <span v-if="log.detail.price" class="ml-2">单价: {{ log.detail.price }}</span>
                  <span v-if="log.detail.cost" class="ml-2">成本: {{ log.detail.cost }}</span>
                  <span v-if="log.detail.profit" class="ml-2">利润: {{ log.detail.profit }}</span>
                  <span v-if="log.detail.sid" class="ml-2">SID: {{ log.detail.sid }}</span>
                  <span v-if="log.detail.amount" class="ml-2">金额: {{ log.detail.amount }}</span>
                  <span v-if="log.detail.account" class="ml-2">账户: {{ log.detail.account }}</span>
                </div>
              </div>
            </div>
            <span class="text-xs text-gray-400 whitespace-nowrap ml-2">{{ new Date(log.time).toLocaleString() }}</span>
          </div>
        </div>
      </div>
    </GlassModal>
  </div>
</template>
