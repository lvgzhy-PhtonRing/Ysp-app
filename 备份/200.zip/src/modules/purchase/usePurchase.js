// 采购模块逻辑层（无 UI）

import { calcItemCost, calcTransferCost } from '../../utils/calc'
import { addOperationLog, saveToLocalStorage, state as store } from '../../data/store'

function toNumber(value, fallback = 0) {
  const n = Number(value)
  return Number.isFinite(n) ? n : fallback
}

function generateItemId() {
  return Date.now() + Math.floor(Math.random() * 1000)
}

function generateTransferId() {
  let id = `tr_${Date.now()}_${Math.floor(Math.random() * 1000)}`
  const exists = (x) => store.transfers.some((t) => t?.transferId === x)
  while (exists(id)) {
    id = `tr_${Date.now()}_${Math.floor(Math.random() * 1000)}`
  }
  return id
}

function generateUniqueTransferBatch(transferData = {}, selectedItems = []) {
  const date = transferData?.date || new Date().toISOString().slice(0, 10)
  const categories = Array.from(new Set(selectedItems.map((i) => i?.category).filter(Boolean)))
  const batches = Array.from(new Set(selectedItems.map((i) => i?.batch).filter(Boolean)))
  const category = categories.length === 1 ? categories[0] : 'MIX'
  const batch = batches.length === 1 ? batches[0] : 'MIX'
  const base = `TR_${date}_${category}_${batch}`

  const existing = new Set((store.transfers || []).map((t) => String(t?.transferBatch || '').trim()).filter(Boolean))
  if (!existing.has(base)) return base

  let seq = 2
  let candidate = `${base}_${seq}`
  while (existing.has(candidate)) {
    seq += 1
    candidate = `${base}_${seq}`
  }
  return candidate
}

function generateNextSid() {
  const maxNo = store.items.reduce((max, item) => {
    const sid = item?.sid
    if (typeof sid !== 'string') return max
    const match = sid.match(/^JP-(\d{4})$/)
    if (!match) return max
    const no = Number(match[1])
    return Number.isFinite(no) ? Math.max(max, no) : max
  }, 0)

  return `JP-${String(maxNo + 1).padStart(4, '0')}`
}

function recalcTransferItemsByTransferId(transferId) {
  if (!transferId) return

  const transfer = store.transfers.find((t) => t?.transferId === transferId)
  if (!transfer) return

  const sameTransferItems = store.items.filter(
    (item) => item?.purchaseDetails?.transferId === transferId,
  )

  if (sameTransferItems.length === 0) return

  const totalCoefficients = sameTransferItems.reduce(
    (sum, item) => sum + toNumber(item?.purchaseDetails?.transferCoefficient, 1),
    0,
  )

  sameTransferItems.forEach((item) => {
    const coefficient = toNumber(item?.purchaseDetails?.transferCoefficient, 1)
    const preTransferCost = toNumber(item?.purchaseDetails?.preTransferCost, 0)
    const transferCost = calcTransferCost(transfer.totalRMB, coefficient, totalCoefficients || 1)

    item.purchaseDetails.transferCost = transferCost
    item.cost = calcItemCost(preTransferCost, transferCost)
  })
}

export function addPurchaseItem(itemData = {}) {
  const purchaseDetails = {
    ...(itemData.purchaseDetails || {}),
  }

  const preTransferCost = toNumber(purchaseDetails.preTransferCost, 0)

  const item = {
    ...itemData,
    id: generateItemId(),
    sid: generateNextSid(),
    status: 'purchase',
    cost: preTransferCost,
    purchaseDetails: {
      transferStatus: 'pending',
      transferCoefficient: 1,
      transferCost: 0,
      ...purchaseDetails,
      preTransferCost,
    },
  }

  store.items.push(item)
  addOperationLog('purchase_add', `新增采购: ${item.name}`, { sid: item.sid, category: item.category, batch: item.batch })
  return item
}

export function submitTransfer(transferData = {}, selectedItemIds = []) {
  const selectedSet = new Set(selectedItemIds)
  const selectedItems = store.items.filter((item) => selectedSet.has(item.id))
  if (selectedItems.length === 0) return null

  const transferId = transferData.transferId || generateTransferId()
  const transferBatch = String(transferData.transferBatch || '').trim() || generateUniqueTransferBatch(transferData, selectedItems)

  const transferRecord = {
    ...transferData,
    transferId,
    transferBatch,
    itemIds: selectedItems.map((item) => item.id),
  }
  store.transfers.push(transferRecord)

  const totalCoefficients = selectedItems.reduce(
    (sum, item) => sum + toNumber(item?.purchaseDetails?.transferCoefficient, 1),
    0,
  )

  selectedItems.forEach((item) => {
    const coefficient = toNumber(item?.purchaseDetails?.transferCoefficient, 1)
    const preTransferCost = toNumber(item?.purchaseDetails?.preTransferCost, 0)
    const transferCost = calcTransferCost(transferRecord.totalRMB, coefficient, totalCoefficients || 1)

    item.purchaseDetails = {
      ...(item.purchaseDetails || {}),
      transferId,
      transferBatch: transferRecord.transferBatch,
      transferStatus: 'completed',
      transferCost,
    }

    item.cost = calcItemCost(preTransferCost, transferCost)
  })

  saveToLocalStorage()
  addOperationLog('purchase_transfer', `提交转运: ${transferRecord.transferBatch || transferId}`, {
    transferId,
    count: selectedItems.length,
    totalRMB: transferRecord.totalRMB,
  })
  return transferRecord
}

export function moveToInventory(itemId) {
  const item = store.items.find((x) => x.id === itemId)
  if (!item) return false

  const transferId = item?.purchaseDetails?.transferId
  if (transferId) {
    store.items.forEach((x) => {
      if (x?.purchaseDetails?.transferId === transferId && x.status === 'purchase') {
        x.status = 'inventory'
      }
    })
    saveToLocalStorage()
    addOperationLog('purchase_to_inventory', `同转运批次整组入库: ${item.name}`, { sid: item.sid, transferId })
    return true
  }

  item.status = 'inventory'
  saveToLocalStorage()
  addOperationLog('purchase_to_inventory', `移入库存: ${item.name}`, { sid: item.sid })
  return true
}

export function batchMoveToInventory(itemIds = []) {
  const idSet = new Set(itemIds)

  store.items.forEach((item) => {
    if (idSet.has(item.id)) {
      item.status = 'inventory'
    }
  })

  saveToLocalStorage()
  addOperationLog('purchase_batch_to_inventory', `批量移入库存`, { count: itemIds.length })
}

export function deletePurchaseItem(itemId) {
  const idx = store.items.findIndex((x) => x.id === itemId)
  if (idx < 0) return false

  const target = store.items[idx]
  const transferId = target?.purchaseDetails?.transferId

  store.items.splice(idx, 1)

  if (transferId) {
    recalcTransferItemsByTransferId(transferId)
  }

  saveToLocalStorage()
  addOperationLog('purchase_delete', `删除采购商品: ${target?.name || itemId}`, { sid: target?.sid, transferId })
  return true
}

export function usePurchase() {
  return {
    addPurchaseItem,
    submitTransfer,
    moveToInventory,
    batchMoveToInventory,
    deletePurchaseItem,
  }
}
